Upload ZIP through Overleaf > New Project > Upload Project.
Main file: main.tex. Compiler: pdfLaTeX.
Faculty proposal and detailed protocol are separate documents.
Study parameters require faculty agreement; no participant findings are asserted.
